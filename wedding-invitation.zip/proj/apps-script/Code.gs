/**
 * Wedding RSVP backend (Google Apps Script web app).
 * Open the Google Sheet > Extensions > Apps Script, paste this file, run setup() once.
 */
var TAB = 'RSVPs';
var TZ = 'Asia/Kolkata';
var HEADERS = ['Submitted (IST)', 'Updated', 'Response ID', 'Name', 'Status', 'Wedding', 'Reception', 'Guests', 'Message'];
var STATUSES = ['Joyfully Accepts', 'Not Sure Yet', 'Sending Love From Afar'];
var MIN_FILL_MS = 2500;
var MAX_PER_MINUTE = 40;

function setup() {
  var props = PropertiesService.getScriptProperties();
  if (!props.getProperty('SECRET')) {
    props.setProperty('SECRET', Utilities.getUuid() + Utilities.getUuid());
  }
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(TAB);
  if (!sh) {
    var sheets = ss.getSheets();
    if (sheets.length === 1 && sheets[0].getLastRow() <= 1) { sh = sheets[0]; sh.setName(TAB); }
    else { sh = ss.insertSheet(TAB); }
  }
  sh.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]).setFontWeight('bold');
  sh.setFrozenRows(1);
  sh.getRange('C:C').setNumberFormat('@');
  Logger.log('Setup complete. Now deploy as a web app.');
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function doGet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var secret = !!PropertiesService.getScriptProperties().getProperty('SECRET');
  var sh = ss.getSheetByName(TAB);
  return json_({ ok: true, service: 'rsvp', secret: secret, sheet: ss.getName(), tab: TAB, ready: secret && !!sh });
}

function sign_(id) {
  var secret = PropertiesService.getScriptProperties().getProperty('SECRET');
  var bytes = Utilities.computeHmacSha256Signature(id, secret);
  return bytes.map(function (b) { var v = (b < 0 ? b + 256 : b).toString(16); return v.length === 1 ? '0' + v : v; }).join('');
}

function clean_(v, max) {
  var s = String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
  if (/^[=+\-@]/.test(s)) s = "'" + s;   // stop spreadsheet formulas
  return s;
}

function yesNo_(v) { return v === 'Yes' ? 'Yes' : (v === 'No' ? 'No' : ''); }

function throttled_() {
  var cache = CacheService.getScriptCache();
  var key = 'rate_' + Math.floor(Date.now() / 60000);
  var n = Number(cache.get(key) || 0) + 1;
  cache.put(key, String(n), 120);
  return n > MAX_PER_MINUTE;
}

function doPost(e) {
  var data;
  try { data = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: 'rejected' }); }
  if (!data || typeof data !== 'object') return json_({ ok: false, error: 'rejected' });

  var lock = LockService.getScriptLock();
  try { lock.waitLock(10000); } catch (err) { return json_({ ok: false, error: 'busy' }); }
  try {
    var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(TAB);
    if (!sh || !PropertiesService.getScriptProperties().getProperty('SECRET')) return json_({ ok: false, error: 'failed' });

    if (data.action === 'get') return get_(sh, data);

    if (data.action !== 'submit' && data.action !== 'update') return json_({ ok: false, error: 'rejected' });
    if (data.website) return json_({ ok: false, error: 'rejected' });            // honeypot
    if (Number(data.elapsed) < MIN_FILL_MS || isNaN(Number(data.elapsed))) return json_({ ok: false, error: 'too_fast' });

    var name = clean_(data.name, 80);
    var status = String(data.status || '');
    var guests = Math.floor(Number(data.guests));
    if (name.length < 2 || STATUSES.indexOf(status) < 0 || !(guests >= 1 && guests <= 20)) return json_({ ok: false, error: 'rejected' });
    var message = clean_(data.message, 400);
    var wed = yesNo_(data.wedding), rec = yesNo_(data.reception);
    var now = Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH:mm:ss');

    if (data.action === 'submit') {
      if (throttled_()) return json_({ ok: false, error: 'busy' });
      var id = Utilities.getUuid().replace(/-/g, '').slice(0, 12);
      sh.appendRow([now, '', id, name, status, wed, rec, guests, message]);
      return json_({ ok: true, id: id, token: sign_(id) });
    }

    // update
    var id2 = String(data.id || '');
    if (sign_(id2) !== String(data.token || '')) return json_({ ok: false, error: 'forbidden' });
    var row = find_(sh, id2);
    if (!row) return json_({ ok: false, error: 'not_found' });
    sh.getRange(row, 2, 1, 1).setValue(now);
    sh.getRange(row, 4, 1, 6).setValues([[name, status, wed, rec, guests, message]]);
    return json_({ ok: true, id: id2, token: data.token });
  } catch (err) {
    return json_({ ok: false, error: 'failed' });
  } finally {
    lock.releaseLock();
  }
}

function find_(sh, id) {
  var last = sh.getLastRow();
  if (last < 2) return 0;
  var ids = sh.getRange(2, 3, last - 1, 1).getValues();
  for (var i = 0; i < ids.length; i++) if (String(ids[i][0]) === id) return i + 2;
  return 0;
}

function get_(sh, data) {
  var id = String(data.id || '');
  if (sign_(id) !== String(data.token || '')) return json_({ ok: false, error: 'forbidden' });
  var row = find_(sh, id);
  if (!row) return json_({ ok: false, error: 'not_found' });
  var v = sh.getRange(row, 1, 1, HEADERS.length).getValues()[0];
  var un = function (s) { return String(s).replace(/^'/, ''); };
  return json_({ ok: true, rsvp: { name: un(v[3]), status: v[4], wedding: v[5], reception: v[6], guests: v[7], message: un(v[8]) } });
}
