export const EASE: [number, number, number, number] = [0.22, 1, 0.36, 1]

export const asset = (p: string) => `${import.meta.env.BASE_URL}${p.replace(/^\//, '')}`

const WD = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
const MO = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
const pad = (n: number) => String(n).padStart(2, '0')

// Shows the clock time of the event's own time zone (taken from the +05:30 in the ISO string).
function local(iso: string): Date {
  const m = iso.match(/([+-])(\d\d):(\d\d)$/)
  const off = m ? (m[1] === '-' ? -1 : 1) * (Number(m[2]) * 60 + Number(m[3])) : 0
  return new Date(new Date(iso).getTime() + off * 60000)
}
export const fmtWeekday = (iso: string) => WD[local(iso).getUTCDay()]
export const fmtDate = (iso: string) => {
  const d = local(iso)
  return `${d.getUTCDate()} ${MO[d.getUTCMonth()]} ${d.getUTCFullYear()}`
}
export const fmtTime = (iso: string) => {
  const d = local(iso)
  const h = d.getUTCHours()
  return `${h % 12 || 12}:${pad(d.getUTCMinutes())} ${h >= 12 ? 'PM' : 'AM'}`
}

export function youtubeId(url: string): string | null {
  const m = url.match(/(?:youtu\.be\/|v=|embed\/|shorts\/)([A-Za-z0-9_-]{11})/)
  return m ? m[1] : null
}
