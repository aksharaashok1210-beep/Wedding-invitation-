// ONE place for everything you may want to change later.
export type EventInfo = {
  id: 'wedding' | 'reception'
  title: string
  start: string // ISO with time zone offset
  end?: string
  auspicious?: string // e.g. Muhurtham
  venue: string
  town: string
  mapUrl: string
}

export const wedding = {
  showPlaceholders: false, // set to false when launching
  siteTitle: 'Ambadi & Akshara | Wedding Invitation',
  couple: { first: 'Ambadi', second: 'Akshara' },
  timeZoneLabel: 'IST',
  eyebrow: 'Together with our families',
  welcomeLine: 'we joyfully invite you to celebrate our wedding',
  // Section order. Sections without content (film) are skipped automatically.
  sectionOrder: ['welcome', 'invitation', 'families', 'film', 'rsvp', 'closing', 'moments'] as const,
  events: [
    {
      id: 'wedding',
      title: 'Wedding Ceremony',
      start: '2027-04-08T12:05:00+05:30',
      end: '2027-04-08T12:25:00+05:30',
      auspicious: 'Muhurtham',
      venue: 'Crown Conversation Centre',
      town: 'Pathanapuram, Kerala',
      mapUrl: 'https://maps.app.goo.gl/r7RWuZAqjffeN8658?g_st=ic',
    },
    {
      id: 'reception',
      title: 'Reception',
      start: '2027-04-08T17:30:00+05:30',
      venue: 'Green Valley Convention Centre',
      town: 'Adoor, Kerala',
      mapUrl: 'https://maps.app.goo.gl/iSF6xhDGUCukgAKt8?g_st=ic',
    },
  ] as EventInfo[],
  families: {
    heading: 'With the blessings of our families',
    // Please edit this text in your own words.
    story:
      'After seven years of friendship, patience and love, we are beginning a new chapter together, with the blessings of our parents and the people we hold dear. Your presence will make our day complete.',
    groom: {
      label: 'Groom’s family',
      lines: ['Raveendran Nair A K', 'Bindhu Krishnan'],
      address: 'Eruthikkamalayil, Kalanjoor P O, Pathanamthitta',
    },
    bride: {
      label: 'Bride’s family',
      lines: ['Ashok Kumar V T', 'Sreelekha M S'],
      address: 'Maranattu Mannil, Kalanjoor P O, Pathanamthitta',
    },
  },
  video: null as null | { url: string; thumb: string }, // e.g. { url: 'https://youtu.be/...', thumb: 'photos/video-thumb.jpg' }
  countdown: { eyebrow: 'Every moment brings us closer...', title: 'Until we say I do' },
  rsvp: { minSeconds: 2.5, maxGuests: 20 },
  closing: {
    message: 'Your love and blessings are the most precious gift we could ask for. We cannot wait to celebrate with you.',
    signature: 'With love, Ambadi & Akshara',
  },
  photos: {
    hero: 'photos/hero.jpg',
    heroBw: 'photos/hero-bw.jpg',
    closingWide: 'photos/closing.jpg',
    closingPortrait: 'photos/closing-4x5.jpg',
  },
  gallery: {
    heading: 'Our Little Moments, Our Forever Memories',
    // Add new photos here later.
    items: [
      { src: 'photos/gallery-01.jpg', alt: 'Ambadi and Akshara by the old stone wall' },
      { src: 'photos/gallery-02.jpg', alt: 'Walking together along the garden path' },
      { src: 'photos/gallery-03.jpg', alt: 'A quiet moment in the sunlight' },
      { src: 'photos/gallery-04.jpg', alt: 'A happy glance while walking' },
      { src: 'photos/gallery-05.jpg', alt: 'Looking at each other under the trees' },
      { src: 'photos/gallery-06.jpg', alt: 'Holding hands by the old wall' },
    ],
  },
  colors: {
    ivory: '#FBF8F1',
    champagne: '#F5EDDE',
    charcoal: '#2a2522',
    chocolate: '#22160c',
  },
}

export const RSVP_ENDPOINT = (import.meta.env.VITE_RSVP_ENDPOINT as string | undefined) ?? ''
