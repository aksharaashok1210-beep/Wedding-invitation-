import { useCallback, useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { wedding } from '../config/wedding'
import { asset, EASE } from '../lib/utils'

export default function Gallery() {
  const items = wedding.gallery.items
  const [open, setOpen] = useState<number | null>(null)
  const step = useCallback((d: number) => setOpen((o) => (o === null ? o : (o + d + items.length) % items.length)), [items.length])

  useEffect(() => {
    if (open === null) return
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(null); if (e.key === 'ArrowRight') step(1); if (e.key === 'ArrowLeft') step(-1) }
    window.addEventListener('keydown', k)
    return () => window.removeEventListener('keydown', k)
  }, [open, step])

  return (
    <section id="moments" className="bg-ivory px-4 pb-24 pt-8">
      <h2 className="pretty mx-auto max-w-md text-center text-3xl font-medium sm:text-4xl">{wedding.gallery.heading}</h2>
      <div className="mx-auto mt-10 grid max-w-5xl grid-cols-2 gap-3 md:grid-cols-3">
        {items.map((it, i) => (
          <motion.button key={it.src} onClick={() => setOpen(i)} aria-label={`Open photo ${i + 1}`} className="group relative aspect-[2/3] overflow-hidden rounded-sm" initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-30px' }} transition={{ duration: 0.9, ease: EASE, delay: (i % 3) * 0.12 }}>
            <img src={asset(it.src)} alt={it.alt} loading="lazy" className="h-full w-full object-cover" />
            <span className="absolute inset-0 bg-ivory/0 transition-colors duration-500 group-hover:bg-ivory/25" />
          </motion.button>
        ))}
      </div>

      <AnimatePresence>
        {open !== null && (
          <motion.div className="fixed inset-0 z-50 grid place-items-center bg-black/90" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(null)} role="dialog" aria-modal="true" aria-label="Photo viewer">
            <motion.img
              key={open} src={asset(items[open].src)} alt={items[open].alt}
              className="max-h-[82svh] max-w-[94vw] select-none object-contain" onClick={(e) => e.stopPropagation()}
              drag="x" dragConstraints={{ left: 0, right: 0 }} dragElastic={0.4}
              onDragEnd={(_, info) => { if (info.offset.x < -60) step(1); else if (info.offset.x > 60) step(-1) }}
              initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.4, ease: EASE }}
            />
            <div className="absolute inset-x-0 bottom-4 flex items-center justify-center gap-3" onClick={(e) => e.stopPropagation()}>
              <button onClick={() => step(-1)} className="label rounded-full border border-white/40 px-4 py-3 text-white" aria-label="Previous photo">‹</button>
              <a href={asset(items[open].src)} download className="label rounded-full border border-white/40 px-4 py-3 text-white">Download</a>
              <button onClick={() => step(1)} className="label rounded-full border border-white/40 px-4 py-3 text-white" aria-label="Next photo">›</button>
            </div>
            <button onClick={() => setOpen(null)} className="label absolute right-4 top-4 rounded-full border border-white/40 px-4 py-3 text-white" aria-label="Close">Close</button>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  )
}
