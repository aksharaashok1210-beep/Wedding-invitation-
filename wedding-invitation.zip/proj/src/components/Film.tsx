import { useState } from 'react'
import { motion } from 'motion/react'
import { wedding } from '../config/wedding'
import { asset, EASE, youtubeId } from '../lib/utils'

export default function Film() {
  const v = wedding.video
  const [playing, setPlaying] = useState(false)
  if (!v) return null
  const id = youtubeId(v.url)
  if (!id) return null
  return (
    <section id="film" className="grain bg-charcoal px-5 py-20">
      <motion.div
        className="relative mx-auto aspect-video max-w-3xl overflow-hidden rounded-sm border border-gold/40"
        initial={{ clipPath: 'inset(35% 25% 35% 25%)' }}
        whileInView={{ clipPath: 'inset(0% 0% 0% 0%)' }}
        viewport={{ once: true, margin: '-80px' }}
        transition={{ duration: 1.4, ease: EASE }}
      >
        {playing ? (
          <iframe className="absolute inset-0 h-full w-full" src={`https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0`} title="Our story" allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen />
        ) : (
          <button onClick={() => setPlaying(true)} className="absolute inset-0 h-full w-full" aria-label="Play our film">
            <img src={asset(v.thumb)} alt="" className="h-full w-full object-cover" />
            <span className="absolute inset-0 grid place-items-center">
              <motion.span className="grid h-16 w-16 place-items-center rounded-full border border-gold bg-black/30 text-gold" animate={{ boxShadow: ['0 0 0 0 rgba(184,151,90,.5)', '0 0 0 22px rgba(184,151,90,0)'] }} transition={{ duration: 2, repeat: Infinity }}>
                ▶
              </motion.span>
            </span>
          </button>
        )}
      </motion.div>
    </section>
  )
}
