import { useRef } from 'react'
import { motion, useScroll, useSpring, useTransform, useReducedMotion, type MotionValue } from 'motion/react'
import Heart from './Heart'

const HEARTS = [
  { left: '10%', top: 55, size: 12, speed: 40 },
  { left: '27%', top: 30, size: 9, speed: -30 },
  { left: '44%', top: 65, size: 14, speed: 55 },
  { left: '61%', top: 25, size: 10, speed: -45 },
  { left: '78%', top: 60, size: 12, speed: 35 },
  { left: '90%', top: 35, size: 9, speed: -25 },
]

function Drift({ p, h }: { p: MotionValue<number>; h: (typeof HEARTS)[number] }) {
  const y = useTransform(p, [0, 1], [h.speed, -h.speed])
  const opacity = useTransform(p, [0, 0.25, 0.75, 1], [0, 0.8, 0.8, 0])
  return (
    <motion.span style={{ position: 'absolute', left: h.left, top: `${h.top}%`, y, opacity }}>
      <Heart size={h.size} />
    </motion.span>
  )
}

// Soft gradient between two sections, with tiny hearts that drift as you scroll (and drift back).
export default function SectionBridge({ from, to, height = 140 }: { from: string; to: string; height?: number }) {
  const ref = useRef<HTMLDivElement>(null)
  const reduce = useReducedMotion()
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] })
  const p = useSpring(scrollYProgress, { stiffness: 80, damping: 22, mass: 0.4 })
  return (
    <div
      ref={ref}
      aria-hidden="true"
      style={{ height, marginTop: -1, marginBottom: -1, position: 'relative', background: `linear-gradient(to bottom, ${from}, ${to})`, pointerEvents: 'none', overflow: 'hidden' }}
    >
      {!reduce && HEARTS.map((h, i) => <Drift key={i} p={p} h={h} />)}
    </div>
  )
}
