import { useEffect, useRef, useState } from 'react'
import { motion, useScroll, useSpring, useTransform } from 'motion/react'
import QRCode from 'qrcode'
import { wedding, type EventInfo } from '../config/wedding'
import { EASE, fmtDate, fmtTime, fmtWeekday } from '../lib/utils'

function Qr({ url }: { url: string }) {
  const [src, setSrc] = useState('')
  useEffect(() => {
    QRCode.toDataURL(url, { margin: 1, width: 220, color: { dark: '#22160c', light: '#FBF8F1' } }).then(setSrc).catch(() => setSrc(''))
  }, [url])
  if (!src) return <div className="h-24 w-24" />
  return <img src={src} alt="QR code for the map" width={96} height={96} className="h-24 w-24 rounded-sm" />
}

function Card({ e, from }: { e: EventInfo; from: 'left' | 'right' }) {
  const time = e.end ? `${fmtTime(e.start)} to ${fmtTime(e.end)}` : fmtTime(e.start)
  return (
    <motion.article
      initial={{ opacity: 0, x: from === 'left' ? -60 : 60 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 1.1, ease: EASE }}
      className="mx-auto w-full max-w-sm rounded-sm border border-gold/40 bg-white/55 px-6 py-8 text-center"
    >
      <p className="label text-gold">{e.title}</p>
      <p className="mt-4 text-2xl font-medium">{fmtWeekday(e.start)}</p>
      <p className="text-3xl font-medium nowrap">{fmtDate(e.start)}</p>
      <p className="mt-3 italic">{time} {wedding.timeZoneLabel}</p>
      {e.auspicious && <p className="label mt-1 text-gold">{e.auspicious}</p>}
      <p className="mt-5 text-xl font-medium">{e.venue}</p>
      <p className="italic">{e.town}</p>
      <a href={e.mapUrl} target="_blank" rel="noopener noreferrer" className="label mt-5 inline-block border border-gold px-5 py-3 text-ink transition-colors hover:bg-gold hover:text-white">
        Open in Google Maps
      </a>
      <div className="mt-5 flex justify-center"><Qr url={e.mapUrl} /></div>
    </motion.article>
  )
}

function Branch({ draw, leaf, flip }: { draw: any; leaf: any; flip?: boolean }) {
  return (
    <svg viewBox="0 0 200 90" className="h-auto w-1/2" style={{ transform: flip ? 'scaleX(-1)' : undefined }} aria-hidden="true">
      <motion.path d="M0 50 C 40 20, 80 80, 130 45 S 185 40, 200 45" fill="none" stroke="#B8975A" strokeWidth="1.4" strokeLinecap="round" style={{ pathLength: draw }} />
      {[[30, 34, -30], [60, 62, 40], [95, 44, -35], [120, 58, 35], [155, 38, -30], [180, 48, 25]].map(([x, y, r], i) => (
        <motion.ellipse key={i} cx={x} cy={y} rx="9" ry="4" fill="#B8975A" fillOpacity="0.35" stroke="#B8975A" strokeWidth="0.8" transform={`rotate(${r} ${x} ${y})`} style={{ opacity: leaf }} />
      ))}
    </svg>
  )
}

export default function Invitation() {
  const ref = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 0.9', 'start 0.2'] })
  const p = useSpring(scrollYProgress, { stiffness: 80, damping: 24, mass: 0.4 })
  const draw = useTransform(p, [0, 0.8], [0, 1])
  const leaf = useTransform(p, [0.4, 1], [0, 1])
  return (
    <section id="invitation" ref={ref} className="bg-ivory px-5 pb-16 pt-6">
      <div className="mx-auto flex max-w-3xl">
        <Branch draw={draw} leaf={leaf} />
        <Branch draw={draw} leaf={leaf} flip />
      </div>
      <p className="label mt-2 text-center text-gold">You are invited</p>
      <div className="mx-auto mt-10 grid max-w-4xl gap-8 md:grid-cols-2">
        {wedding.events.map((e, i) => <Card key={e.id} e={e} from={i % 2 === 0 ? 'left' : 'right'} />)}
      </div>
      <motion.div className="mx-auto mt-14 h-px max-w-xs bg-gold/70" initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 1.4, ease: EASE }} />
    </section>
  )
}
