import { motion } from 'motion/react'
import { wedding } from '../config/wedding'
import { EASE } from '../lib/utils'
import Heart from './Heart'

const rise = { initial: { opacity: 0, y: 24 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true, margin: '-40px' }, transition: { duration: 1, ease: EASE } }

export default function Families() {
  const f = wedding.families
  const side = (s: typeof f.groom) => (
    <motion.div {...rise} className="text-center">
      <p className="label text-gold">{s.label}</p>
      <p className="mt-3 text-2xl font-medium">{s.lines.map((n) => <span key={n} className="nowrap block">{n}</span>)}</p>
      <p className="pretty mt-2 italic">{s.address}</p>
    </motion.div>
  )
  return (
    <section id="families" className="bg-champagne px-6 py-20">
      <div className="mx-auto max-w-xl text-center">
        <motion.div {...rise} className="flex justify-center"><Heart size={22} /></motion.div>
        <motion.h2 {...rise} className="mt-4 text-3xl font-medium sm:text-4xl">{f.heading}</motion.h2>
        <motion.p {...rise} className="pretty mt-6 leading-relaxed">{f.story}</motion.p>
        <div className="mt-12 grid gap-10 sm:grid-cols-2">
          {side(f.groom)}
          {side(f.bride)}
        </div>
      </div>
    </section>
  )
}
