import { useRef } from 'react'
import { motion, useScroll, useSpring, useTransform, useReducedMotion } from 'motion/react'
import { wedding } from '../config/wedding'
import { asset, EASE, fmtDate, fmtWeekday } from '../lib/utils'
import Heart from './Heart'

function Letters({ text, delay }: { text: string; delay: number }) {
  return (
    <span className="nowrap inline-block" aria-label={text}>
      {text.split('').map((c, i) => (
        <motion.span key={i} aria-hidden="true" className="inline-block" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, ease: EASE, delay: delay + i * 0.07 }}>
          {c}
        </motion.span>
      ))}
    </span>
  )
}

export default function Hero() {
  const ref = useRef<HTMLElement>(null)
  const reduce = useReducedMotion()
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] })
  const p = useSpring(scrollYProgress, { stiffness: 90, damping: 26, mass: 0.4 })
  const colour = useTransform(p, [0, 0.55], [0, 1])
  const scale = useTransform(p, [0, 1], [1, 1.12])
  const y = useTransform(p, [0, 1], ['0%', '10%'])
  const hint = useTransform(p, [0, 0.12], [1, 0])
  const first = wedding.events[0]

  return (
    <section id="welcome" ref={ref} className="relative" style={{ height: '170svh' }}>
      <div className="sticky top-0 h-svh overflow-hidden grain bg-ivory">
        <motion.div className="absolute inset-0" style={{ scale, y }}>
          <img src={asset(wedding.photos.heroBw)} alt="" className="absolute inset-0 h-full w-full object-cover" style={{ objectPosition: '50% 28%' }} />
          <motion.img src={asset(wedding.photos.hero)} alt="Ambadi and Akshara" className="absolute inset-0 h-full w-full object-cover" style={{ objectPosition: '50% 28%', opacity: colour }} />
        </motion.div>
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(251,248,241,.35) 0%, rgba(251,248,241,0) 28%, rgba(251,248,241,.72) 62%, #FBF8F1 100%)' }} />

        {!reduce && (
          <div className="pointer-events-none absolute inset-0" aria-hidden="true">
            {[12, 30, 50, 68, 86].map((l, i) => (
              <motion.span key={l} className="absolute" style={{ left: `${l}%`, bottom: '12%' }} initial={{ y: 0, opacity: 0 }} animate={{ y: -380, opacity: [0, 0.8, 0] }} transition={{ duration: 9 + i * 1.5, repeat: Infinity, delay: i * 1.7, ease: 'easeOut' }}>
                <Heart size={10 + (i % 3) * 3} />
              </motion.span>
            ))}
          </div>
        )}

        <div className="absolute inset-x-0 bottom-0 px-5 pb-24 text-center">
          <motion.p className="label text-gold" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.2, delay: 0.3 }}>
            {wedding.eyebrow}
          </motion.p>
          <h1 className="mt-3 flex flex-wrap items-baseline justify-center gap-x-3 font-serif font-medium leading-[1.05] text-ink" style={{ fontSize: 'clamp(2.6rem, 11vw, 5.8rem)' }}>
            <Letters text={wedding.couple.first} delay={0.6} />
            <motion.span className="text-gold italic" initial={{ opacity: 0, scale: 0.6 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.9, ease: EASE, delay: 1.5 }}>
              &amp;
            </motion.span>
            <Letters text={wedding.couple.second} delay={1.7} />
          </h1>
          <motion.p className="pretty mx-auto mt-4 max-w-md italic" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.2, delay: 2.5 }}>
            {wedding.welcomeLine}
          </motion.p>
          <motion.p className="label mt-4 text-ink/80" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.2, delay: 2.8 }}>
            {fmtWeekday(first.start)} · {fmtDate(first.start)}
          </motion.p>
        </div>

        <motion.div className="absolute inset-x-0 bottom-3 flex flex-col items-center" style={{ opacity: hint }} aria-hidden="true">
          <div className="h-8 w-px bg-gold/70" />
          <motion.div style={{ transformOrigin: 'top center' }} animate={reduce ? undefined : { rotate: [-7, 7, -7] }} transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut' }}>
            <Heart size={18} />
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
