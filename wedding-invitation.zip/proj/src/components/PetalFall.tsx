import { useEffect, useRef } from 'react'
import { useReducedMotion } from 'motion/react'
import { asset } from '../lib/utils'

type Petal = { img: HTMLImageElement; x0: number; y: number; w: number; h: number; speed: number; amp: number; freq: number; phase: number; rot: number; rotSpeed: number; t: number }

// A very light rose-petal finish: only while scrolling down, never more than 12 on screen.
export default function PetalFall() {
  const reduce = useReducedMotion()
  const ref = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (reduce) return
    const canvas = ref.current
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx) return

    let W = 0, H = 0
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      W = window.innerWidth; H = window.innerHeight
      canvas.width = W * dpr; canvas.height = H * dpr
      canvas.style.width = W + 'px'; canvas.style.height = H + 'px'
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()
    window.addEventListener('resize', resize)

    const imgs: HTMLImageElement[] = []
    for (const set of ['red', 'pink', 'ivory']) {
      for (let i = 1; i <= 8; i++) { const im = new Image(); im.src = asset(`petals/${set}-${i}.png`); imgs.push(im) }
    }

    let petals: Petal[] = []
    let raf = 0, last = 0, lastY = window.scrollY, acc = 0

    const spawn = () => {
      const ready = imgs.filter((i) => i.complete && i.naturalWidth > 0)
      if (!ready.length || petals.length >= 12) return
      const img = ready[Math.floor(Math.random() * ready.length)]
      const w = W < 640 ? 11 + Math.random() * 6 : 14 + Math.random() * 6
      const h = w * (img.naturalHeight / img.naturalWidth)
      petals.push({
        img, x0: Math.random() * W, y: -h, w, h,
        speed: 25 + Math.random() * 20, amp: 12 + Math.random() * 14, freq: 0.5 + Math.random() * 0.5,
        phase: Math.random() * 6.28, rot: Math.random() * 6.28, rotSpeed: (Math.random() < 0.5 ? -1 : 1) * (0.2 + Math.random() * 0.4), t: 0,
      })
      if (!raf) { last = 0; raf = requestAnimationFrame(tick) }
    }

    const tick = (now: number) => {
      const dt = last ? Math.min((now - last) / 1000, 0.05) : 0
      last = now
      ctx.clearRect(0, 0, W, H)
      petals = petals.filter((p) => p.y < H)
      for (const p of petals) {
        p.t += dt; p.y += p.speed * dt; p.rot += p.rotSpeed * dt
        const x = p.x0 + Math.sin(p.t * p.freq + p.phase) * p.amp
        const fade = p.y < H * 0.5 ? 1 : Math.max(0, 1 - (p.y - H * 0.5) / (H * 0.5))
        ctx.globalAlpha = 0.85 * fade
        ctx.save(); ctx.translate(x, p.y); ctx.rotate(p.rot)
        ctx.drawImage(p.img, -p.w / 2, -p.h / 2, p.w, p.h)
        ctx.restore()
      }
      ctx.globalAlpha = 1
      if (petals.length) raf = requestAnimationFrame(tick)
      else { raf = 0; ctx.clearRect(0, 0, W, H) }
    }

    const onScroll = () => {
      const y = window.scrollY, d = y - lastY
      lastY = y
      if (d > 0) {
        acc += d
        if (acc > 380) { acc = 0; spawn(); if (Math.random() < 0.3) spawn() }
      } else acc = 0
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => {
      window.removeEventListener('scroll', onScroll); window.removeEventListener('resize', resize)
      if (raf) cancelAnimationFrame(raf)
    }
  }, [reduce])

  if (reduce) return null
  return <canvas ref={ref} aria-hidden="true" style={{ position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 40 }} />
}
