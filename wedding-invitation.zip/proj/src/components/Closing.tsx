import { useRef } from 'react'
import { motion, useScroll, useSpring, useTransform } from 'motion/react'
import { wedding } from '../config/wedding'
import { asset, EASE } from '../lib/utils'

export default function Closing() {
  const ref = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] })
  const p = useSpring(scrollYProgress, { stiffness: 80, damping: 24, mass: 0.4 })
  const opacity = useTransform(p, [0.05, 0.3], [0, 1])
  const scale = useTransform(p, [0.05, 0.6], [1.08, 1])
  const y = useTransform(p, [0, 1], ['-4%', '4%'])
  const choc = wedding.colors.chocolate
  const mask = 'linear-gradient(to bottom, transparent 0%, #000 22%, #000 62%, transparent 100%)'
  return (
    <section id="closing" ref={ref} className="grain relative overflow-hidden" style={{ background: choc }}>
      {/* Phones: the 4:5 photo, complete, fading into dark at the bottom */}
      <motion.div className="relative md:hidden" style={{ opacity, scale }}>
        <img src={asset(wedding.photos.closingPortrait)} alt="Ambadi and Akshara holding hands" className="block w-full" style={{ aspectRatio: '4 / 5', objectFit: 'cover', WebkitMaskImage: 'linear-gradient(to bottom, #000 55%, transparent 100%)', maskImage: 'linear-gradient(to bottom, #000 55%, transparent 100%)' }} />
      </motion.div>
      {/* Laptops: photo over a blurred copy of itself, edges softly masked */}
      <motion.div className="relative hidden h-[110svh] overflow-hidden md:block" style={{ opacity }}>
        <img src={asset(wedding.photos.closingWide)} alt="" aria-hidden="true" className="absolute inset-0 h-full w-full scale-125 object-cover opacity-60 blur-2xl" />
        <motion.img src={asset(wedding.photos.closingWide)} alt="Ambadi and Akshara holding hands" className="absolute left-1/2 top-0 h-full -translate-x-1/2 object-contain" style={{ scale, y, WebkitMaskImage: mask, maskImage: mask }} />
        <div className="absolute inset-x-0 bottom-0 h-1/3" style={{ background: `linear-gradient(to bottom, transparent, ${choc})` }} />
      </motion.div>
      <div className="relative z-10 -mt-24 px-6 pb-24 text-center md:-mt-40">
        <motion.p initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 1.1, ease: EASE }} className="pretty mx-auto max-w-md text-xl italic text-ivory">
          {wedding.closing.message}
        </motion.p>
        <motion.p initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ duration: 1.4, delay: 0.3 }} className="label mt-6 text-gold">
          {wedding.closing.signature}
        </motion.p>
      </div>
    </section>
  )
}
