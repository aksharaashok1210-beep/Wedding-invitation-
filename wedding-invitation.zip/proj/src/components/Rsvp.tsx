import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { wedding, RSVP_ENDPOINT } from '../config/wedding'
import { EASE } from '../lib/utils'
import Heart from './Heart'

const STATUSES = ['Joyfully Accepts', 'Not Sure Yet', 'Sending Love From Afar'] as const
type Status = (typeof STATUSES)[number]

function useCountdown(target: number) {
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t) }, [])
  const s = Math.max(0, Math.floor((target - now) / 1000))
  return { done: target - now <= 0, d: Math.floor(s / 86400), h: Math.floor((s % 86400) / 3600), m: Math.floor((s % 3600) / 60), s: s % 60 }
}

function Burst() {
  return (
    <div className="pointer-events-none absolute left-1/2 top-10" aria-hidden="true">
      {Array.from({ length: 12 }).map((_, i) => {
        const a = (i / 12) * Math.PI * 2
        return (
          <motion.span key={i} className="absolute" initial={{ x: 0, y: 0, opacity: 1, scale: 0.4 }} animate={{ x: Math.cos(a) * 90, y: Math.sin(a) * 90, opacity: 0, scale: 1 }} transition={{ duration: 1.4, ease: EASE }}>
            <Heart size={14} />
          </motion.span>
        )
      })}
    </div>
  )
}

const variants = {
  enter: (d: number) => ({ x: d * 40, opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (d: number) => ({ x: d * -40, opacity: 0 }),
}

const ERRORS: Record<string, string> = {
  too_fast: 'That was a little quick. Please wait a moment and try again.',
  busy: 'Many replies are arriving right now. Please try again in a minute.',
  rejected: 'We could not accept that reply. Please check your answers.',
  forbidden: 'This edit link is not valid.',
  not_found: 'We could not find that reply.',
}

export default function Rsvp() {
  const wed = wedding.events[0]
  const two = wedding.events.length === 2
  const cd = useCountdown(new Date(wed.start).getTime())

  const [step, setStep] = useState(0)
  const [dir, setDir] = useState(1)
  const [name, setName] = useState('')
  const [status, setStatus] = useState<Status | ''>('')
  const [guests, setGuests] = useState(1)
  const [atWedding, setAtWedding] = useState(true)
  const [atReception, setAtReception] = useState(true)
  const [message, setMessage] = useState('')
  const [website, setWebsite] = useState('') // honeypot
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [editLink, setEditLink] = useState('')
  const [copied, setCopied] = useState(false)
  const [editing, setEditing] = useState<{ id: string; token: string } | null>(null)
  const startedAt = useRef(Date.now())

  const go = (to: number) => { setDir(to > step ? 1 : -1); setStep(to); setError('') }
  const attending = status === 'Joyfully Accepts' || status === 'Not Sure Yet'

  // Open a private edit link: ?edit=ID&t=TOKEN
  useEffect(() => {
    const q = new URLSearchParams(window.location.search)
    const id = q.get('edit'), token = q.get('t')
    if (!id || !token || !RSVP_ENDPOINT) return
    post({ action: 'get', id, token }).then((r) => {
      if (r.ok && r.rsvp) {
        setEditing({ id, token }); setName(r.rsvp.name); setStatus(r.rsvp.status); setGuests(Number(r.rsvp.guests) || 1)
        setAtWedding(r.rsvp.wedding === 'Yes'); setAtReception(r.rsvp.reception === 'Yes'); setMessage(r.rsvp.message || '')
        document.getElementById('rsvp')?.scrollIntoView()
      }
    }).catch(() => {})
  }, [])

  async function post(body: object): Promise<any> {
    const res = await fetch(RSVP_ENDPOINT, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(body) })
    return res.json()
  }

  async function submit() {
    setError('')
    if (!RSVP_ENDPOINT) { go(3); return }
    setBusy(true)
    try {
      const payload = {
        action: editing ? 'update' : 'submit', id: editing?.id, token: editing?.token,
        name, status, wedding: attending && atWedding ? 'Yes' : 'No', reception: two ? (attending && atReception ? 'Yes' : 'No') : '',
        guests: attending ? guests : 1, message, website, elapsed: Date.now() - startedAt.current,
      }
      const r = await post(payload)
      if (!r.ok) { setError(ERRORS[r.error] ?? 'Something went wrong. Please try again.'); return }
      const id = r.id ?? editing?.id, token = r.token ?? editing?.token
      if (id && token) setEditLink(`${window.location.origin}${window.location.pathname}?edit=${id}&t=${token}`)
      go(3)
    } catch {
      setError('We could not reach the server. Please check your connection and try again.')
    } finally { setBusy(false) }
  }

  const box = 'rounded-sm border border-gold/40 bg-white/60 px-4 py-3 text-ink'
  const btn = 'label border border-gold px-6 py-3 text-ink transition-colors hover:bg-gold hover:text-white disabled:opacity-40'

  return (
    <section id="rsvp" className="bg-ivory px-5 py-20">
      <div className="mx-auto max-w-xl text-center">
        <p className="label text-gold">{wedding.countdown.eyebrow}</p>
        <h2 className="mt-3 text-3xl font-medium sm:text-4xl">{wedding.countdown.title}</h2>
        {cd.done ? (
          <p className="mt-8 text-2xl italic">Today is the day.</p>
        ) : (
          <div className="mt-8 grid grid-cols-4 gap-2 sm:gap-4" role="timer" aria-label="Time until the wedding">
            {([['Days', cd.d], ['Hours', cd.h], ['Minutes', cd.m], ['Seconds', cd.s]] as const).map(([l, v]) => (
              <div key={l} className="rounded-sm border border-gold/40 py-4">
                <div className="text-3xl font-medium tabular-nums sm:text-4xl">{String(v).padStart(2, '0')}</div>
                <div className="label mt-1 text-gold" style={{ fontSize: '.6rem' }}>{l}</div>
              </div>
            ))}
          </div>
        )}

        <div className="relative mx-auto mt-14 min-h-[22rem] overflow-hidden rounded-sm border border-gold/30 bg-champagne/60 px-5 py-8">
          <p className="label text-gold">{editing ? 'Update your reply' : 'Kindly reply'}</p>
          <AnimatePresence mode="wait" custom={dir} initial={false}>
            <motion.div key={step} custom={dir} variants={variants} initial="enter" animate="center" exit="exit" transition={{ duration: 0.45, ease: EASE }} className="mt-6">
              {step === 0 && (
                <div>
                  <label htmlFor="rsvp-name" className="text-xl">May we have your name?</label>
                  <input id="rsvp-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} autoComplete="name" className={`${box} mt-4 w-full text-center`} />
                  {/* honeypot: hidden from people */}
                  <input tabIndex={-1} autoComplete="off" value={website} onChange={(e) => setWebsite(e.target.value)} aria-hidden="true" style={{ position: 'absolute', left: '-9999px', opacity: 0, height: 0, width: 0 }} name="website" />
                  <div className="mt-6"><button className={btn} disabled={name.trim().length < 2} onClick={() => go(1)}>Next</button></div>
                </div>
              )}
              {step === 1 && (
                <div>
                  <p className="text-xl">Will you join us?</p>
                  <div className="mt-4 grid gap-3">
                    {STATUSES.map((s) => (
                      <button key={s} onClick={() => setStatus(s)} aria-pressed={status === s} className={`${box} flex items-center justify-center gap-3 ${status === s ? 'border-gold bg-white' : ''}`}>
                        <motion.span animate={status === s ? { scale: [1, 1.6, 1] } : { scale: 1 }} transition={{ duration: 0.5 }}><Heart size={18} filled={status === s} /></motion.span>
                        {s}
                      </button>
                    ))}
                  </div>
                  <div className="mt-6 flex justify-center gap-3">
                    <button className={btn} onClick={() => go(0)}>Back</button>
                    <button className={btn} disabled={!status} onClick={() => go(2)}>Next</button>
                  </div>
                </div>
              )}
              {step === 2 && (
                <div>
                  {attending && (
                    <>
                      <p className="text-xl">How many guests, including you?</p>
                      <div className="mt-3 flex items-center justify-center gap-5">
                        <button className={btn} onClick={() => setGuests((g) => Math.max(1, g - 1))} aria-label="Fewer guests">−</button>
                        <div className="relative h-10 w-12 overflow-hidden text-3xl" aria-live="polite">
                          <AnimatePresence mode="popLayout" initial={false}>
                            <motion.span key={guests} className="absolute inset-0" initial={{ y: 18, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -18, opacity: 0 }} transition={{ duration: 0.25 }}>{guests}</motion.span>
                          </AnimatePresence>
                        </div>
                        <button className={btn} onClick={() => setGuests((g) => Math.min(wedding.rsvp.maxGuests, g + 1))} aria-label="More guests">+</button>
                      </div>
                      {two && (
                        <div className="mt-5 grid gap-2 text-left">
                          <p className="text-center text-xl">Which events will you attend?</p>
                          <label className="flex items-center gap-3"><input type="checkbox" checked={atWedding} onChange={(e) => setAtWedding(e.target.checked)} /> Wedding Ceremony</label>
                          <label className="flex items-center gap-3"><input type="checkbox" checked={atReception} onChange={(e) => setAtReception(e.target.checked)} /> Reception</label>
                        </div>
                      )}
                    </>
                  )}
                  <label htmlFor="rsvp-msg" className="mt-5 block text-xl">A message for us (optional)</label>
                  <textarea id="rsvp-msg" value={message} onChange={(e) => setMessage(e.target.value)} maxLength={400} rows={3} className={`${box} mt-3 w-full`} />
                  {error && <p role="alert" className="mt-3 text-sm text-red-800">{error}</p>}
                  <div className="mt-5 flex justify-center gap-3">
                    <button className={btn} onClick={() => go(1)}>Back</button>
                    <button className={btn} disabled={busy} onClick={submit}>{busy ? 'Sending…' : editing ? 'Save changes' : 'Send reply'}</button>
                  </div>
                </div>
              )}
              {step === 3 && (
                <div className="relative pt-4">
                  <Burst />
                  <motion.div className="flex justify-center" animate={{ scale: [1, 1.18, 1] }} transition={{ duration: 1.3, repeat: Infinity }}><Heart size={44} filled color="#B8975A" /></motion.div>
                  <p className="mt-5 text-2xl font-medium">Thank you, {name.trim().split(' ')[0]}.</p>
                  {!RSVP_ENDPOINT ? (
                    <p className="mt-3 text-base italic">Preview only: the RSVP is not connected yet, so nothing was sent or saved.</p>
                  ) : (
                    <>
                      <p className="mt-3 italic">Your reply has been saved.</p>
                      {editLink && (
                        <div className="mt-5 text-base">
                          <p>Need to change your answer later? Keep this private link:</p>
                          <p className="mt-2 break-all text-sm text-gold">{editLink}</p>
                          <button className={`${btn} mt-3`} onClick={() => { navigator.clipboard?.writeText(editLink); setCopied(true) }}>{copied ? 'Copied' : 'Copy link'}</button>
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  )
}
