import { Fragment, type ReactNode } from 'react'
import { wedding } from './config/wedding'
import Hero from './components/Hero'
import Invitation from './components/Invitation'
import Families from './components/Families'
import Film from './components/Film'
import Rsvp from './components/Rsvp'
import Closing from './components/Closing'
import Gallery from './components/Gallery'
import SectionBridge from './components/SectionBridge'
import PetalFall from './components/PetalFall'

const c = wedding.colors
const SECTIONS: Record<string, { node: ReactNode; colour: string; show: () => boolean }> = {
  welcome: { node: <Hero />, colour: c.ivory, show: () => true },
  invitation: { node: <Invitation />, colour: c.ivory, show: () => true },
  families: { node: <Families />, colour: c.champagne, show: () => true },
  film: { node: <Film />, colour: c.charcoal, show: () => !!wedding.video },
  rsvp: { node: <Rsvp />, colour: c.ivory, show: () => true },
  closing: { node: <Closing />, colour: c.chocolate, show: () => true },
  moments: { node: <Gallery />, colour: c.ivory, show: () => true },
}

export default function App() {
  const list = wedding.sectionOrder.filter((k) => SECTIONS[k].show())
  return (
    <main>
      {list.map((k, i) => (
        <Fragment key={k}>
          {i > 0 && <SectionBridge from={SECTIONS[list[i - 1]].colour} to={SECTIONS[k].colour} height={k === 'closing' ? 200 : 140} />}
          {SECTIONS[k].node}
        </Fragment>
      ))}
      <PetalFall />
    </main>
  )
}
