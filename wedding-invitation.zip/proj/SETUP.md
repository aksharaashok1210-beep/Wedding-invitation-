# RSVP setup (about 10 minutes)

Your guests' replies go into your private Google Sheet: **Ambadi & Akshara | Wedding RSVP 2027**.

1. Open the sheet.
2. Click **Extensions > Apps Script**.
3. Delete everything in the editor, then paste the whole of `apps-script/Code.gs`.
4. At the top, choose the function **setup** and click **Run**. Approve the permissions when Google asks
   (click "Advanced", then "Go to project"). This creates the secret and the "RSVPs" tab.
5. Click **Deploy > New deployment**. Click the gear icon and choose **Web app**.
   - Execute as: **Me**
   - Who has access: **Anyone** (not "Anyone with Google account")
6. Click **Deploy** and copy the link that ends in `/exec`.
7. Open that link in your browser. You should see `"ok":true ... "ready":true`.
8. Put the link in the website: in Vercel, open your project > **Settings > Environment Variables**,
   add `VITE_RSVP_ENDPOINT` with the `/exec` link, then **Redeploy**. (For local work, put it in the `.env` file.)

## After you change Code.gs
**Deploy > Manage deployments > pencil icon > Version: New version > Deploy.** The link stays the same.

## Testing
The RSVP cannot be tested in Claude's preview. Test it on the real website: send one reply, check that a row appears
in the "RSVPs" tab, then open the private edit link on the thank-you screen and change the answer.
